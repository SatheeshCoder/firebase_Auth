export const navigations=[
    {
        name: "Dashboard",
        path: "/dashboard/default",
        icon: "dashboard",
    },{
        name: "Customer List",
        path: "/customerList",
        icon: "people",
    },{
        name: "Users",
        path: "/usersList",
        icon: "people",
    }
]