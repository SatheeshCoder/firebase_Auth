export const firebaseConfig = {
  apiKey: "AIzaSyDQu1l7h2tryuJwXjMRMBFwerDj6nhaBY8",
  authDomain: "dashboard-a2016.firebaseapp.com",
  projectId: "dashboard-a2016",
  databaseURL: "https://dashboard-a2016-default-rtdb.firebaseio.com",
  storageBucket: "dashboard-a2016.firebasestorage.app",
  messagingSenderId: "152776201191",
  appId: "1:152776201191:web:f74b87f4f20d7c8f826342",
  measurementId: "G-5M3Z5XZMP1"
};

